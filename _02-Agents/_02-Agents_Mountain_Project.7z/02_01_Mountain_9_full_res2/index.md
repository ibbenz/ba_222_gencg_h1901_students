---
layout: sketch
title: "Mountain_09_full_resolution" 
category: "Experiment" 
thumb_name: "thumb.jpg"
includes:
  - src: "sketch.js"
---

<!-- 

  You can change the title, category and thumb as you like 
  (just make sure the folder contain a jpg for the thumb with the correct name)
  Do not change the first line "layout: sketch"

  If you need to customize this html page:
    1) delete the line "layout: sketch"
    2) copy the content of "/_layouts/sketch.html" below. 
    Make sure to leave one line of space between the markup above and the html code

-->